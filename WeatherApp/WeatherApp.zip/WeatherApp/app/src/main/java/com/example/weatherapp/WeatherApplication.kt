package com.example.weatherapp

import dagger.hilt.android.HiltAndroidApp
import android.app.Application


@HiltAndroidApp
class WeatherApplication : Application()