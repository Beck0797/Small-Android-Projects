package com.example.weatherapp.data.models

data class Condition(
    val code: Int,
    val icon: String,
    val text: String
)