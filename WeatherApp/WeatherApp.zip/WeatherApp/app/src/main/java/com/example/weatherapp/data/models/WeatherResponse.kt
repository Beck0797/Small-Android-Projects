package com.example.weatherapp.data.models

data class WeatherResponse(
    val current: Current,
    val location: Location
)